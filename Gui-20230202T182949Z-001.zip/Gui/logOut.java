/*
Name: Harguntas Singh Benipal
Teacher Name: Mr. Bains
Course : ICS4U0-A
Date: January 27, 2023
Description: This is the logOut class that logs the user out of the program. It calls system.exit(0). 
*/

import javax.swing.*; //Import swing library

public class logOut 
{ //Name of Class

	public logOut () 
	{ //Constructor
		JOptionPane.showMessageDialog(null, "Have a great day"); //Outputs message
		System.exit(0); //Exits program	
	} //End of constructor
	
} //End of class
